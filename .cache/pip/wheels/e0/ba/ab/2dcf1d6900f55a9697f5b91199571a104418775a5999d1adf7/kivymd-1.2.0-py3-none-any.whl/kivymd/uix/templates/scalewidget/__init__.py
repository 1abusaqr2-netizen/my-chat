from .scalewidget import ScaleWidget
